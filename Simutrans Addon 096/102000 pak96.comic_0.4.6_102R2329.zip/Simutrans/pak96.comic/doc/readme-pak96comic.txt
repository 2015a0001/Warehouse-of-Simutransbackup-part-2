﻿-----------------------------
         Readme 
for pak96.comic for Simutrans
-----------------------------

This graficset can't run without the programm simutrans. Make sure that you have installed this game.

Pak96.comic is not only for model railroad players. But you can have a lot of fun with this virtuell transporting simulation as an model railroad player.


-----------------
----- INDEX -----
-----------------

1. Which version have I to use?
2. Where can I find more informations?
3. I have a bug or a wish
4. Copyright & Licence
5. Imprint
6. Thanks and Team




1. Which version have I to use?
-------------------------------

Have a look at the zip-file or into the changelists.

The zip-file can tell you the version:

pak96.comic_Version Graficset_Version Simutrans.zip




2. Where can I find more informations?
--------------------------------------

pak96.comic home (in german, english (mayby not the best) and a little bit in cz):
http://simutrans.piranho.de/

Simutrans Mainpage to choose your language:
http://simutrans.com/

Simutrans forum in many languages:
http://forum.simutrans.com/

Simutrans forum in german:
http://www.simutrans-forum.de/forum/




3. I have a bug or a wish
-------------------------

Make a posting at the forum in german or in english.




4. Copyright & Licence
----------------------

Pak96.comic is freeware. You can play or share it with friends and other people.

But pak96.comic is not open source. You can not take some objects from this graficset and put it on your own project.

If you are not sure about what you can do and what not. Send me an email or make a posting in the forums.

The copyright for all objects are by the team from pak96.comic or by the painter.



5. Imprint
----------

Look for "sojo" in the german or international form. I'm the maintainer of pak96.comic.

Sven Osada
Trakehnerstraße 23
06124 Halle (Germany)

sven.osada@googlemail.com



6. Thanks and Team
------------------

Many thanks to the programmers, in particular to Hajo and Prissi.


Many thanks to the master of grafics Alexander Brose.


More grafic-artists:
E-44
Luki Haba
MHz
Noel
Qayyum
The Transporter
Tomas
vilvoh


Thanks to the wiki writer Frank Penz and mister 'nightly' Wernieman.


Other VIPs:
Dirk
DirrtyDirk
VS

-----------------------
This document is created by sojo 28.02.2009